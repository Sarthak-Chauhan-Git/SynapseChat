import Logoimg from "./assets/Logo.png";

export default function Logo() {
  return (
    <>
      <img src={Logoimg} alt="" />
    </>
  );
}
